package Selenium_API_testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class API_test {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\hp\\Downloads\\Selenium\\EXE\\chrome\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		String u = "yesheb42069@gmail.com";
		
		driver.get("http://www.gmail.com/");
		driver.findElement(By.id("identifierId")).sendKeys(u);
		//driver.findElement(By.className("_2hvTZ pexuQ zyHYP")).sendKeys(p);
		driver.findElement(By.id("identifierNext")).click();
		
		String at = driver.getTitle();
		String r = "Gmail";
		
		
		
		driver.close();
	
		//Test Case (Returns the name of the Web Page!)
		if(at.equalsIgnoreCase(r)){
			
			System.out.println("Test Success");
		}
		else {
			System.out.println("Test Failure");
		}

	}

}
